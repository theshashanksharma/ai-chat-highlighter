const $=s=>document.querySelector(s),KEY='chatmarkerCloud',LOCAL='chatmarkerHighlights';
const DEFAULT_SUPABASE_URL='https://bjwfllctduzznueblkfp.supabase.co';
const DEFAULT_SUPABASE_KEY='sb_publishable_MecAou53PFKntC03-mC3cA_kHiE3eNj';
async function getCfg(){return (await chrome.storage.local.get({[KEY]:null}))[KEY]}
function say(s){$('#status').textContent=s}
async function saveSettings(){const old=await getCfg()||{};const url=$('#url').value.trim().replace(/\/+$/,'');const anonKey=$('#anon').value.trim();if(!/^https:\/\/[^/]+\.supabase\.co$/.test(url)||!anonKey){say('Enter a valid Supabase project URL and public anon/publishable key.');return false}await chrome.storage.local.set({[KEY]:{...old,url,anonKey}});say('Project settings saved.');return true}
async function auth(mode){const c=await getCfg(),email=$('#email').value.trim(),password=$('#password').value;if(!email||!password){say('Enter your email and password.');return}try{const endpoint=mode==='signup'?'/auth/v1/signup':'/auth/v1/token?grant_type=password';const r=await fetch(c.url+endpoint,{method:'POST',headers:{apikey:c.anonKey,'Content-Type':'application/json'},body:JSON.stringify({email,password})});const d=await r.json();if(!r.ok)throw new Error(d.msg||d.message||d.error_description||d.error||'Authentication failed');if(!d.access_token){say('Account created. Check your email to confirm it, then sign in.');return}await chrome.storage.local.set({[KEY]:{...c,...d,user:d.user||d.session?.user}});say('Signed in. Syncing local highlights…');await syncAll();say('Signed in and synced. Your existing highlights were kept.')}catch(e){say('Could not sign in: '+e.message)}}
async function api(path,opts={}){const c=await getCfg();const r=await fetch(c.url+path,{...opts,headers:{apikey:c.anonKey,Authorization:'Bearer '+c.access_token,'Content-Type':'application/json',...(opts.headers||{})}});if(!r.ok)throw new Error('Cloud sync failed ('+r.status+'): '+(await r.text()).slice(0,180));return r.status===204?[]:r.text().then(t=>t?JSON.parse(t):[])}
function mapRow(x,userId){return {id:x.id,user_id:userId,text:x.text,message_index:x.messageIndex??0,message_text:x.messageText||'',role:x.role||'assistant',message_id:x.messageId||'',turn_id:x.turnId||'',before_context:x.before||'',after_context:x.after||'',color:x.color||'yellow',note:x.note||'',conversation_url:x.url||'',title:x.title||'',created_at:new Date(x.createdAt||Date.now()).toISOString(),updated_at:new Date().toISOString()}}
async function syncAll(){
 const c=await getCfg();if(!c?.access_token||!c?.user?.id){say('Sign in first.');return}
 const local=(await chrome.storage.local.get({[LOCAL]:[]}))[LOCAL]||[];
 const remote=await api('/rest/v1/highlights?select=*&order=created_at.desc');
 const known=new Set((remote||[]).map(x=>x.id));
 const missing=local.filter(x=>!known.has(x.id));
 if(missing.length)await api('/rest/v1/highlights?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(missing.map(x=>mapRow(x,c.user.id)))});
 const refreshed=missing.length?await api('/rest/v1/highlights?select=*&order=created_at.desc'):remote;
 const merged=new Map(local.map(x=>[x.id,x]));
 for(const x of (refreshed||[])){if(x.deleted_at){merged.delete(x.id);continue}if(!merged.has(x.id))merged.set(x.id,{id:x.id,text:x.text,messageIndex:x.message_index||0,messageText:x.message_text||'',role:x.role||'assistant',messageId:x.message_id||'',turnId:x.turn_id||'',before:x.before_context||'',after:x.after_context||'',color:x.color||'yellow',note:x.note||'',url:x.conversation_url||'',title:x.title||'',createdAt:new Date(x.created_at).getTime()})}
 await chrome.storage.local.set({[LOCAL]:[...merged.values()]});
}
$('#login').onclick=()=>auth('login');$('#signup').onclick=()=>auth('signup');$('#logout').onclick=async()=>{const c=await getCfg();if(c?.url&&c?.access_token)fetch(c.url+'/auth/v1/logout',{method:'POST',headers:{apikey:c.anonKey,Authorization:'Bearer '+c.access_token}}).catch(()=>{});await chrome.storage.local.set({[KEY]:{url:c?.url||'',anonKey:c?.anonKey||''}});say('Signed out. Local highlights remain on this computer.')};
(async()=>{let c=await getCfg();c={...(c||{}),url:c?.url||DEFAULT_SUPABASE_URL,anonKey:c?.anonKey||DEFAULT_SUPABASE_KEY};await chrome.storage.local.set({[KEY]:c});if(c.access_token){$('#email').value=c.user?.email||'';say('Signed in as '+(c.user?.email||'your account')+'.')}else{say('Create an account or sign in to sync your highlights.')}})();
