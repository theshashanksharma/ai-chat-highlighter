-- ChatMarker Supabase setup
-- Run this entire script in Supabase Dashboard > SQL Editor.
create table if not exists public.highlights (
  id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null default 'chatgpt' check (platform in ('chatgpt','claude','gemini','other')),
  text text not null,
  message_index integer not null default 0,
  message_text text not null default '',
  role text not null default 'assistant',
  message_id text not null default '',
  turn_id text not null default '',
  before_context text not null default '',
  after_context text not null default '',
  color text not null default 'yellow' check (color in ('yellow','green','blue','pink')),
  note text not null default '',
  conversation_url text not null default '',
  title text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz null
);
alter table public.highlights add column if not exists deleted_at timestamptz null;
alter table public.highlights enable row level security;
drop policy if exists "Users can read their own highlights" on public.highlights;
drop policy if exists "Users can insert their own highlights" on public.highlights;
drop policy if exists "Users can update their own highlights" on public.highlights;
drop policy if exists "Users can delete their own highlights" on public.highlights;
create policy "Users can read their own highlights" on public.highlights for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert their own highlights" on public.highlights for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update their own highlights" on public.highlights for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete their own highlights" on public.highlights for delete to authenticated using (auth.uid() = user_id);
create index if not exists highlights_user_created_idx on public.highlights(user_id, created_at desc);

-- Safe migration for existing ChatMarker Cloud projects
alter table public.highlights add column if not exists platform text not null default 'chatgpt';
