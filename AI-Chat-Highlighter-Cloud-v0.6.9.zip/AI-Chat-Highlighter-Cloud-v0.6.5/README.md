# AI Chat Highlighter Cloud Sync v0.6.3

This package contains:
- Chrome extension with local-first storage plus Supabase cloud sync.
- Mobile-friendly web library (`mobile.html`) for viewing/searching/deleting synced highlights.
- SQL schema and row-level security policies.
- Setup instructions below.

## Before you begin
The extension is preconfigured to use the AI Chat Highlighter Supabase project, including its public publishable key. You do not need to copy these values into the extension. You still need to create an account or sign in before highlights can sync. The key embedded in the client is a public publishable key; database access is restricted by Supabase Row Level Security. Never use a service-role key in the extension or mobile app.

## 1. Create the Supabase backend
1. The connected project has already been created and the `public.highlights` table and Row Level Security policies have been configured.
2. Create an account or sign in in the extension options.
3. In Supabase Authentication settings, ensure your desired email-confirmation policy is configured. If email confirmation is enabled, confirm your account before signing in.

## 2. Configure the Chrome extension
1. Open `chrome://extensions`.
2. Update the existing unpacked extension by copying the extension files from this folder into its existing folder. Do not remove the extension or clear its local storage.
3. Click Reload on the extension card.
4. Open the extension's Details page and click Extension options, or right-click the extension icon and choose Options (wording varies by Chrome).
5. The Project URL and public key are filled automatically.
6. Create an account or sign in. After sign-in, the options page uploads existing local highlights and merges remote highlights.
7. Open or refresh a ChatGPT, Claude, or Gemini conversation. The content script pulls cloud highlights before attempting to paint them.

## 3. Open the mobile library
`mobile.html` is a static web app. To use it on your phone, host `mobile.html`, `mobile.css`, `mobile.js`, and `manifest.webmanifest` on a static HTTPS host such as GitHub Pages, Netlify, or Cloudflare Pages. Do not just open the local file on your phone.
1. Upload those four files to your static hosting provider.
2. Open the published HTTPS URL on your phone.
3. Enter the same Supabase Project URL and public key.
4. Sign in with the same AI Chat Highlighter account.

The mobile library supports search, colour filtering, opening the saved conversation URL and deleting highlights. A Chrome extension cannot inject highlights inside the native ChatGPT, Claude, and Gemini mobile app. The mobile library lets you access saved highlights on your phone; in-chat mobile painting is not included.

## 4. Data and security
- Highlights are stored locally in Chrome and in your Supabase table.
- Supabase Row Level Security restricts reads/writes to the authenticated user's own rows.
- The public anon/publishable key is designed to be used in browser clients. Never use a Supabase service-role key in the extension or mobile app.
- The app stores the Supabase session in Chrome local storage (extension) and browser local storage (mobile app).
- Cloud deletion is synced when a delete action reaches Supabase. If a device is offline, a delete may not reach the cloud until you retry.
- Back up local highlights before major extension changes.

## Current limitations
- Cloud conflict resolution is simple: existing IDs merge; remote records are added if missing. It is not a full offline-first conflict engine.
- On a fresh device, the extension can repaint only conversations it can access and whose text still exists on the ChatGPT, Claude, and Gemini page.
- The mobile web library is a separate app and does not paint inside the ChatGPT, Claude, and Gemini mobile app.
- For public deployment, configure Supabase Auth redirect URLs and your static hosting URL in Supabase Authentication settings.

Version 0.5.1 uses soft-delete tombstones in the cloud so a deleted highlight is not resurrected from another device's stale local copy. It also adds a Cloud sync settings link in the extension popup.


## Supported AI sites (v0.6.0)
AI Chat Highlighter can capture selected text on ChatGPT (`chatgpt.com`), Claude (`claude.ai`), and Gemini (`gemini.google.com`). Saved items include a platform label. The popup labels each item, and the mobile library has category filters for All AI, ChatGPT, Claude, and Gemini. AI sites update their page markup frequently; restoration selectors are best-effort and should be tested on each site.

## Important compatibility note
The extension now injects on the three supported websites. AI Chat Highlighter's general text matching fallback attempts to restore highlights after reload, but Claude and Gemini use different, changing page structures; test selection, restore-after-refresh, and “See in conversation” on each site. Run the updated `supabase-setup.sql` in your existing Supabase project so the `platform` column is added before using cloud sync with this version. Existing rows default to `chatgpt`; new highlights are categorized from their source URL.


## v0.6.2 restoration fix
This build replaces the old text-range reconstruction with a mapped text-node index. Block separators no longer shift DOM offsets, and invisible/scripted text is excluded from matching. Restoration diagnostics now report whether the passage text exists in the visible page body. Existing local storage keys and highlight IDs are preserved.


## v0.6.3 branding update
The extension name and mobile library branding are now AI Chat Highlighter. Added highlighter icon assets (16, 32, 48, 128, 192 and 512 px), SVG source, Chrome extension icons, and web-app favicon/touch icons. Existing local storage keys and Supabase schema are intentionally unchanged.


## v0.6.6 cloud configuration
This build pre-fills the project URL and public publishable key for the connected AI Chat Highlighter Supabase project. Authentication is still required per user. The project database table and Row Level Security policies have been applied.


## v0.6.6 restoration fix
- Improved text-node mapping when rendered AI responses split saved passages across inline elements.
- Added a fallback matching pass that inserts safe boundaries between adjacent text nodes.
- Reduced repeated console warning noise for the same saved passage during retry cycles.


## v0.6.7 restoration safety fix
- Restricts fallback range matching to the smallest visible content/message containers instead of searching and wrapping across the entire document body.
- Refuses unsafe highlight ranges whose common ancestor is the page body or document element.
- Goal: prevent broad DOM extraction/reinsertion that can damage or dim AI conversation rendering.
- Browser-side regression testing is still required on ChatGPT, Claude, and Gemini.


Version 0.6.8 uses the CSS Custom Highlight API to paint selected text without wrapping/replacing conversation DOM nodes, helping avoid broken dynamic Markdown rendering. Requires a modern Chromium browser with CSS Custom Highlight API support.


Version 0.6.9 fixes stale CSS Custom Highlight Range references after AI sites rerender conversation text nodes. Disconnected ranges are pruned and saved highlights are retried against replacement text nodes.
