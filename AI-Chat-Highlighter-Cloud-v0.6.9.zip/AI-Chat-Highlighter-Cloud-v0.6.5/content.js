(() => {
if(window.__chatmarkerLoaded)return;window.__chatmarkerLoaded=true;
const KEY='chatmarkerHighlights';let timer=null,cached=null,applying=false;const failedDiagnostics=new Set();
const paintedRanges=new Map();
const HIGHLIGHT_COLORS=['yellow','green','blue','pink'];
function rangeIsLive(entry){
 try{return !!entry?.range?.startContainer?.isConnected&&!!entry?.range?.endContainer?.isConnected&&entry.range.startContainer.ownerDocument===document&&entry.range.endContainer.ownerDocument===document&&entry.range.toString().trim().length>0}catch(e){return false}
}
function renderHighlights(){
 if(!('highlights' in CSS)||typeof Highlight==='undefined')return false;
 // Frameworks such as React can replace text nodes after a highlight is painted.
 // Drop stale Range objects so restoration can find the replacement text nodes.
 for(const [id,entry] of paintedRanges){if(!rangeIsLive(entry))paintedRanges.delete(id)}
 for(const color of HIGHLIGHT_COLORS){
  const ranges=[...paintedRanges.values()].filter(x=>x.color===color&&rangeIsLive(x)).map(x=>x.range);
  const name='ai-chat-highlighter-'+color;
  if(ranges.length)CSS.highlights.set(name,new Highlight(...ranges));else CSS.highlights.delete(name);
 }
 return true;
}
function clearPaintedRange(id){paintedRanges.delete(id);renderHighlights()}

const CLOUD_KEY='chatmarkerCloud';
async function cloudConfig(){const d=await chrome.storage.local.get({[CLOUD_KEY]:null});return d[CLOUD_KEY]}
async function cloudRequest(path,opts={}){
 const c=await cloudConfig();if(!c?.url||!c?.anonKey||!c?.access_token)return null;
 const url=c.url.replace(/\/+$/,'');
 const headers={apikey:c.anonKey,Authorization:'Bearer '+c.access_token,'Content-Type':'application/json',...(opts.headers||{})};
 let res=await fetch(url+path,{...opts,headers});
 if(res.status===401&&c.refresh_token){
  const rr=await fetch(url+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:c.anonKey,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:c.refresh_token})});
  if(rr.ok){const session=await rr.json();await chrome.storage.local.set({[CLOUD_KEY]:{...c,...session}});headers.Authorization='Bearer '+session.access_token;res=await fetch(url+path,{...opts,headers})}
 }
 if(!res.ok){console.warn('[ChatMarker cloud] request failed',res.status);return null}
 if(res.status===204)return [];
 const raw=await res.text();return raw?JSON.parse(raw):[];
}
function fromCloud(r){return {id:r.id,platform:r.platform||platformFromUrl(r.conversation_url||''),text:r.text,messageIndex:r.message_index??0,messageText:r.message_text||'',role:r.role||'assistant',messageId:r.message_id||'',turnId:r.turn_id||'',before:r.before_context||'',after:r.after_context||'',color:r.color||'yellow',note:r.note||'',url:r.conversation_url||'',title:r.title||'',createdAt:r.created_at?new Date(r.created_at).getTime():Date.now()}}
function toCloud(x,userId){return {id:x.id,user_id:userId,platform:x.platform||platformFromUrl(x.url||''),text:x.text,message_index:x.messageIndex??0,message_text:x.messageText||'',role:x.role||'assistant',message_id:x.messageId||'',turn_id:x.turnId||'',before_context:x.before||'',after_context:x.after||'',color:x.color||'yellow',note:x.note||'',conversation_url:x.url||'',title:x.title||'',created_at:new Date(x.createdAt||Date.now()).toISOString(),updated_at:new Date().toISOString()}}
async function cloudPullAndMerge(){
 const c=await cloudConfig();if(!c?.access_token||!c?.user?.id)return;
 const remote=await cloudRequest('/rest/v1/highlights?select=*&order=created_at.desc');
 if(!remote)return;
 const d=await chrome.storage.local.get({[KEY]:[]}),local=d[KEY]||[],remoteById=new Map(remote.map(x=>[x.id,x]));
 // Tombstones prevent a deleted cloud record from being re-uploaded from stale local storage.
 const merged=new Map(local.map(x=>[x.id,x]));
 for(const row of remote){
  if(row.deleted_at){merged.delete(row.id);continue}
  if(!merged.has(row.id))merged.set(row.id,fromCloud(row));
 }
 await chrome.storage.local.set({[KEY]:[...merged.values()]});
 // First-run migration only uploads records that have never existed in the cloud.
 const knownIds=new Set(remote.map(x=>x.id)),missing=local.filter(x=>!knownIds.has(x.id));
 if(missing.length)await cloudRequest('/rest/v1/highlights?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(missing.map(x=>toCloud(x,c.user.id)))});
}
async function cloudUpsert(item){const c=await cloudConfig();if(!c?.access_token||!c?.user?.id)return;await cloudRequest('/rest/v1/highlights?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(toCloud(item,c.user.id))})}
async function cloudDelete(id){await cloudRequest('/rest/v1/highlights?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({deleted_at:new Date().toISOString(),updated_at:new Date().toISOString()})})}

function platformFromUrl(u){try{const h=new URL(u).hostname;if(h==='claude.ai'||h.endsWith('.claude.ai'))return 'claude';if(h==='gemini.google.com')return 'gemini';if(h==='chatgpt.com'||h==='chat.openai.com')return 'chatgpt';return 'other'}catch(e){return 'other'}}
function urlKey(){return location.origin+location.pathname}
function canonicalUrl(u){try{const x=new URL(u,location.origin);return x.origin+x.pathname.replace(/\/+$/,'')}catch(e){return String(u||'').split(/[?#]/)[0].replace(/\/+$/,'')}}
function textRoots(){return [...new Set([document.querySelector('main'),document.querySelector('[role=main]'),document.body].filter(Boolean))]}

function messages(){
 // Platform-specific selectors first, then broad semantic fallbacks.
 const selectors=[
  '[data-message-author-role="assistant"]','[data-message-author-role="user"]',
  '[data-testid^="conversation-turn-"]','[data-testid*="conversation-turn"]',
  '[data-message-id]','[role="article"]','main article','[role="main"] article',
  'main [data-testid]','[role="main"] [data-testid]'
 ];
 for(const sel of selectors){
  const found=[...document.querySelectorAll(sel)].filter(n=>n.innerText?.trim() && n.getClientRects().length);
  // Prefer leaf-ish message nodes to avoid counting nested wrappers repeatedly.
  const reduced=found.filter(n=>!found.some(other=>other!==n&&n.contains(other)&&norm(other.innerText)===norm(n.innerText)));
  if(reduced.length)return [...new Set(reduced)];
 }
 return [];
}
function closestMsg(el){return el?.closest('[data-message-author-role="assistant"],[data-message-author-role="user"],[data-testid^="conversation-turn-"],[data-testid*="conversation-turn"],[data-message-id],[data-message-author],main article,[role="article"]')||el?.closest('main [class]')||null}
function anchors(m){return {messageId:m?.getAttribute('data-message-id')||m?.getAttribute('data-testid')||'',turnId:m?.closest?.('[data-testid^="conversation-turn-"]')?.getAttribute('data-testid')||''}}
function locate(item,ms){
 const has=(hay,needle)=>norm(hay).includes(norm(needle));
 // First use identifiers if ChatGPT exposes them, but only accept a node that
 // actually contains the saved passage.
 if(item.messageId){
  const e=document.querySelector('[data-message-id="'+CSS.escape(item.messageId)+'"],[data-testid="'+CSS.escape(item.messageId)+'"]');
  if(e){const m=closestMsg(e)||e;if(has(m.innerText,item.text))return m}
 }
 if(item.turnId){
  const e=document.querySelector('[data-testid="'+CSS.escape(item.turnId)+'"]');
  if(e&&has(e.innerText,item.text))return e;
 }
 // Message indices are unstable after reload; use them only if both passage
 // and a meaningful part of the original message still match.
 if(ms[item.messageIndex]&&has(ms[item.messageIndex].innerText,item.text)&&
    (!item.messageText||has(ms[item.messageIndex].innerText,(item.messageText||'').slice(0,100))))return ms[item.messageIndex];
 // Try exact message text next.
 if(item.messageText){
  const e=ms.find(m=>norm(m.innerText)===norm(item.messageText)&&has(m.innerText,item.text));
  if(e)return e;
 }
 // Robust fallback: ChatGPT may split paragraphs or alter whitespace between
 // reloads. Match the selected passage after whitespace normalization.
 let hits=ms.filter(m=>has(m.innerText,item.text));
 if(hits.length===1)return hits[0];
 if(hits.length>1){
  const contextual=hits.find(m=>(!item.before||has(m.innerText,item.before.slice(-80)))&&(!item.after||has(m.innerText,item.after.slice(0,80))));
  if(contextual)return contextual;
  // If multiple messages contain the same common sentence, don't guess.
 }
 return null;
}
function capture(){const sel=getSelection();if(!sel||sel.isCollapsed||!sel.toString().trim())return;const range=sel.getRangeAt(0),node=range.commonAncestorContainer,el=node.nodeType===1?node:node.parentElement,msg=closestMsg(el);if(!msg)return;const ms=messages();let i=ms.indexOf(msg);if(i<0)i=0;cached={range:range.cloneRange(),text:sel.toString().trim(),messageIndex:i,messageText:msg.innerText?.trim().slice(0,5000)||sel.toString().trim(),role:msg.getAttribute('data-message-author-role')||'assistant',...anchors(msg),before:ms[i-1]?.innerText.trim().slice(-500)||'',after:ms[i+1]?.innerText.trim().slice(0,500)||'',url:urlKey(),title:document.title,platform:platformFromUrl(location.href)}}
document.addEventListener('mouseup',()=>setTimeout(capture,0),true);document.addEventListener('keyup',()=>setTimeout(capture,0),true);document.addEventListener('selectionchange',()=>{if(getSelection()?.toString().trim())capture()},true);
function norm(x){return (x||'').replace(/\s+/g,' ').trim().toLowerCase()}
function findRange(root,text){
 if(!root||!text)return null;
 const needle=String(text).replace(/\s+/g,' ').trim();
 if(!needle)return null;
 const buildAndFind=(insertBetweenNodes)=>{
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{
   acceptNode(n){
    if(!n.nodeValue || !n.nodeValue.length || n.parentElement?.closest('[data-chatmarker="true"],script,style,noscript,textarea,input,button,[aria-hidden="true"]'))return NodeFilter.FILTER_REJECT;
    return NodeFilter.FILTER_ACCEPT;
   }
  });
  const chars=[],map=[];let n,previous=null;
  const blockTags=new Set(['P','DIV','LI','BLOCKQUOTE','PRE','H1','H2','H3','H4','H5','H6','BR']);
  while((n=walker.nextNode())){
   if(previous){
    const a=previous.parentElement,b=n.parentElement;
    const separated=insertBetweenNodes || (a!==b && (blockTags.has(a?.tagName)||blockTags.has(b?.tagName)));
    if(separated && chars.length && !/\s/.test(chars[chars.length-1])){chars.push(' ');map.push(null)}
   }
   for(let i=0;i<n.nodeValue.length;i++){chars.push(n.nodeValue[i]);map.push({node:n,offset:i})}
   previous=n;
  }
  let hay='',hmap=[],space=false;
  for(let i=0;i<chars.length;i++){
   const c=chars[i];
   if(/\s/.test(c)){if(!space){hay+=' ';hmap.push(map[i]);space=true}}
   else {hay+=c;hmap.push(map[i]);space=false}
  }
  const lower=hay.toLocaleLowerCase(), target=needle.toLocaleLowerCase();
  let at=lower.indexOf(target);
  // A second occurrence is only useful if first isn't mappable (e.g. synthetic boundary).
  while(at>=0){
   const first=hmap[at],last=hmap[at+target.length-1];
   if(first&&last){
    try{const range=document.createRange();range.setStart(first.node,first.offset);range.setEnd(last.node,last.offset+1);return range}catch(e){}
   }
   at=lower.indexOf(target,at+1);
  }
  return null;
 };
 return buildAndFind(false)||buildAndFind(true);
}
function findRangeAnywhere(text){
 // Never create a Range across the whole page/body: on modern AI sites that can
 // extract and reinsert unrelated conversation nodes, causing dim/broken UI.
 const target=norm(text);
 if(!target)return null;
 const selectors=[
  '[data-message-author-role="assistant"]','[data-message-author-role="user"]',
  '[data-testid^="conversation-turn-"]','[data-testid*="conversation-turn"]',
  '[data-message-id]','[role="article"]','article','main p','main li',
  'main blockquote','main pre','[role="main"] p','[role="main"] li',
  'main div','[role="main"] div'
 ];
 const candidates=new Set();
 for(const sel of selectors){
  for(const el of document.querySelectorAll(sel)){
   if(!el.isConnected||!el.getClientRects().length||el.closest('[data-chatmarker="true"]'))continue;
   const txt=norm(el.innerText||el.textContent||'');
   if(txt.includes(target))candidates.add(el);
  }
 }
 // Search the smallest matching visible container first. Each range stays
 // inside one message/content block and cannot wrap the entire conversation.
 const ordered=[...candidates].sort((a,b)=>{
  const al=(a.innerText||a.textContent||'').length,bl=(b.innerText||b.textContent||'').length;
  return al-bl;
 });
 for(const el of ordered){
  const len=(el.innerText||el.textContent||'').length;
  if(len>Math.max(12000,target.length*20))continue;
  const range=findRange(el,text);
  if(range&&range.startContainer?.isConnected&&range.endContainer?.isConnected)return range;
 }
 return null;
}
function wrap(r,color,id){
 try{
  if(!r||!r.startContainer?.isConnected||!r.endContainer?.isConnected)return null;
  const selected=r.toString();
  if(!selected.trim()||selected.length>12000)return null;
  if(!('highlights' in CSS)||typeof Highlight==='undefined'){
   console.warn('[AI Chat Highlighter] This browser does not support CSS Custom Highlight API; avoiding DOM-mutating fallback.');
   return null;
  }
  const range=r.cloneRange(),safeColor=HIGHLIGHT_COLORS.includes(color)?color:'yellow';
  paintedRanges.set(id,{range,color:safeColor});renderHighlights();
  return {id,range,color:safeColor};
 }catch(e){console.warn('[AI Chat Highlighter] Safe range highlighting failed',e);return null}
}
async function applySaved(){
 if(applying)return;
 applying=true;
 try{
  await cloudPullAndMerge();
  const d=await chrome.storage.local.get({[KEY]:[]});
  const all=d[KEY]||[], here=urlKey(), saved=all.filter(x=>canonicalUrl(x.url)===canonicalUrl(here)), ms=messages();
  console.info('[AI Chat Highlighter diagnostic] restore start',{savedTotal:all.length,savedForThisUrl:saved.length,currentUrl:here,messageCount:ms.length});
  for(const item of saved){
   const existingPaint=paintedRanges.get(item.id);
   if(existingPaint&&rangeIsLive(existingPaint)){continue}
   if(existingPaint){paintedRanges.delete(item.id);renderHighlights()}
   const msg=locate(item,ms);
   // Message selectors can return zero on some ChatGPT layouts. Search the
   // conversation root directly before declaring restoration impossible.
   let r=msg?findRange(msg,item.text):null;
   if(!r) r=findRangeAnywhere(item.text);
   if(!r){
    const diagnosticKey=item.id+'|'+urlKey();
    if(!failedDiagnostics.has(diagnosticKey)){
     failedDiagnostics.add(diagnosticKey);
     console.warn('[AI Chat Highlighter] Saved passage is present but could not be mapped to a text range.',{highlightId:item.id,matchedMessage:!!msg,loadedMessageCount:ms.length,savedPassageLength:(item.text||'').length,bodyTextLength:document.body?.innerText?.length||0,bodyContainsPassage:norm(document.body?.innerText).includes(norm(item.text)),url:location.href});
    }
    continue;
   }
   const mark=wrap(r,item.color,item.id);
   console.info('[AI Chat Highlighter diagnostic] RESTORED',{text:item.text.slice(0,100),color:item.color,painted:!!mark});
  }
 }catch(e){console.error('[AI Chat Highlighter diagnostic] restore error',e)}
 finally{applying=false}
}
function schedule(){clearTimeout(timer);timer=setTimeout(()=>{if(!applying)applySaved()},300)}
function restoreWithRetries(){
 let attempts=0;
 const tick=async()=>{
  await applySaved();
  attempts++;
  if(attempts<30)setTimeout(tick,700);
 };
 tick();
}
function reveal(item){
 const msg=locate(item,messages());let painted=paintedRanges.get(item.id);
 if(!painted){const r=(msg&&findRange(msg,item.text))||findRangeAnywhere(item.text);if(r)painted=wrap(r,item.color||'yellow',item.id)}
 const target=painted?.range?.startContainer,el=target?(target.nodeType===1?target:target.parentElement):msg;
 if(!el)return false;el.scrollIntoView({behavior:'smooth',block:'center'});return true;
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m?.type==='CHATMARKER_SAVE_SELECTION'){const sel=getSelection();if(sel&&!sel.isCollapsed&&sel.toString().trim())capture();const x=cached;if(!x?.range||!x.range.startContainer.isConnected){reply({ok:false,reason:'no-selection'});return} (async()=>{const d=await chrome.storage.local.get({[KEY]:[]}),list=d[KEY]||[];if(list.some(y=>y.url===x.url&&norm(y.text)===norm(x.text))){reply({ok:false,reason:'already-saved'});return}const item={id:crypto.randomUUID(),platform:x.platform||platformFromUrl(location.href),text:x.text,messageIndex:x.messageIndex,messageText:x.messageText,role:x.role,messageId:x.messageId,turnId:x.turnId,before:x.before,after:x.after,color:m.color||'yellow',note:m.note||'',url:x.url,title:x.title,createdAt:Date.now()};if(!wrap(x.range,item.color,item.id)){reply({ok:false,reason:'paint-failed'});return}list.push(item);await chrome.storage.local.set({[KEY]:list});await cloudUpsert(item);reply({ok:true})})().catch(()=>reply({ok:false,reason:'save-failed'}));return true}
if(m?.type==='CHATMARKER_REVEAL'){reply({ok:reveal(m.item)});return}
if(m?.type==='CHATMARKER_DELETE'){cloudDelete(m.id);clearPaintedRange(m.id);schedule();reply({ok:true});return}});
const obs=new MutationObserver(records=>{if(records.some(r=>{const t=r.target.nodeType===1?r.target:r.target.parentElement;return !t?.closest?.('[data-chatmarker="true"]')}))schedule()});obs.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
chrome.storage.onChanged.addListener((c,a)=>{if(a!=='local'||!c[KEY])return;const ids=new Set((c[KEY].newValue||[]).map(x=>x.id));for(const id of paintedRanges.keys())if(!ids.has(id))paintedRanges.delete(id);renderHighlights();schedule()});
restoreWithRetries();
window.addEventListener('pageshow',restoreWithRetries);
window.addEventListener('load',restoreWithRetries);
})();